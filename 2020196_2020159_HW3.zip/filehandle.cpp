//Harris Abdullah 2020159
//Khizar Ali Shah 2020196

#include <iostream>
#include <fstream>
#include <ncurses.h>
#include <unistd.h>
using namespace std;

extern void showString(int, int, string);
extern void spaces(int, int, int);

void insertWord(string val)
{
    fstream myFile("words.txt", ios::in | ios::out);
    
    string w; int x;
    
    while(!myFile.eof())
    {
        int bef = myFile.tellp();
        cout << bef << ": ";
        myFile >> w >> x;
        int aft = myFile.tellp();
        cout << aft << " -> " << w << " " << x << endl;
       
        if(w == val)
        {   
            if(bef != 0)
            {
                myFile.seekg( bef - aft + 1 , ios::cur);
            }
            else
            {
                myFile.seekg( bef - aft , ios::cur);
            }
            myFile << w << " " << ++x << "\n";
            break;
        }
        else if(myFile.fail())
        {
            myFile.clear();
            myFile << val << " 1\n";
            break;
        }
    }

    myFile.close();
}

void showFrequentWords(char ch, int place, string ans, string freqWords[])
{

    int highest1=3, highest2=2, highest3=1;
    int totalFound = 0;
    string word; int count;

    fstream myFile("words.txt", ios::in);
    bool runAgain = false;
    
    while( !myFile.eof() )
    {
        if(myFile.fail())
            return;
        runAgain = false;
        myFile >> word >> count;

        if(word[place] == ch)
        {
            for(int i=0; i<place; ++i)
            {
                if(word[i] != ans[i])
                {
                    runAgain = true;
                    break;
                }
            }

            if(runAgain)
                continue;

            if(count > highest1)
            {
                if(freqWords[0] != "-")
                {
                    if(freqWords[1] != "-")
                    {
                        highest3 = highest2;
                        freqWords[2] = freqWords[1];  
                    }
                    highest2 = highest1;
                    freqWords[1] = freqWords[0];
                }
                freqWords[0] = word;
                highest1 = count;
            }
            else if(count > highest2)
            {
                if(freqWords[1] != "-")
                {
                    highest3 = highest2;
                    freqWords[2] = freqWords[1];
                }
                freqWords[1] = word;
                highest2 = count;
            }
            else if(count >= highest3)
            {
                freqWords[2] = word;
                highest3 = count;
            }
        }
    }

    myFile.close();

    string fullStr = freqWords[0]+"\t"+freqWords[1]+"\t"+freqWords[2];

    refresh();
    spaces(20, 20, 100);
    showString(20, 20, fullStr);
    refresh();
}

