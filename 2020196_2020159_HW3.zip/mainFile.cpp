//Harris Abdullah 2020159
//Khizar Ali Shah 2020196

#include <iostream>
#include <fstream>
#include <ncurses.h>
#include <string>
#include <unistd.h>
using namespace std;

extern string login();
extern void welcome(string);
extern void learnMessage();
extern string askQuestion(string, string w="x", int lastPlace=-1);
extern void insertWord(string);
extern void giveHints(char);

int main()
{
    initscr();
    
    welcome(login());
    learnMessage();

    //UP key = to select the first suggestion
    //DOWN key = to select second suggestion
    //LEFT key = to select third suggestion

    insertWord(askQuestion("How are you feeling today? "));
    insertWord(askQuestion("Your best friend? "));
    insertWord(askQuestion("Your favorite food? "));
    insertWord(askQuestion("Your favorite subject? "));
    insertWord(askQuestion("Your hobby? "));
    
    endwin();
    
    return 0;
}